# Dicoding Collection Dashboard ✨

## Setup environment

conda create --name main-ds python=3.9
conda activate main-ds
pip install numpy pandas scipy matplotlib seaborn jupyter streamlit babel

library 

Babel==2.14.0
matplotlib==3.7.1
pandas==1.5.3
seaborn==0.13.2
streamlit==1.32.0


1. Download or clone all file in https://github.com/naufalsahli/ProjekDataAnalisis 
2. Description of files:

all_data.csv = data to be used
Projek_Data_Analisis.ipynb = file used for data analysis on all_data.csv
dashboard.py = file to display obtained data
requirements.txt = libraries used in Projek_Data_Analisis.ipynb and dashboard.py

## Run steamlit app

1. Install streamlit 
    - ! pip install streamlit -q
2. Upload dashboard.py 
3. use dan run
    - !wget -q -O - ipv4.icanhazip.com
    to get the local IP
4. use dan run
    - ! streamlit run dashboard.py & npx localtunnel --port 8501
5. click
    - your url is: https://XXXXXXXXXX.loca.lt 
6. Enter the local IP obtained from step 3
7. Submit and run
    

